A Pen created at CodePen.io. You can find this one at http://codepen.io/Cool_Cat/pen/JKwEKN.

 